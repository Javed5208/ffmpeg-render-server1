# FFmpeg Render Server
Deploy on Render.com. Provides /render-final API for video polishing.
Set ENV: SUPABASE_URL, SUPABASE_KEY, SUPABASE_BUCKET.
